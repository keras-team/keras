## Adding a new Ruby version

Use one of the scripts `script/update-*` to add a new Ruby version.

## Updating OpenSSL

Use `script/update-openssl`.
